# Python Shelly Statistic
